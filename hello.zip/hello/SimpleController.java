package com.meenweerawat.hello;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.meenweerawat.hello.modellab.BankAccount;
import com.meenweerawat.hello.modellab.BankAccountRepository;

@RestController
public class SimpleController {
	  @Autowired
	  public BankAccountRepository bankAccountRepository;
	  
	  @RequestMapping("/")
	  public String home() {
		  return "Get /account to see all account, "+
				 "Post /account to add new account, "+
				 "Put /{id} to update account, "+
				 "Delete /{id} to delete account, ";
		  }
	  
		@PostMapping("/account")
		public BankAccount addAccount (@RequestBody BankAccount bankAccount) {
			return bankAccountRepository.save(bankAccount);
			
		}
		@GetMapping("/account")
		public List<BankAccount> getAccount(){
		Iterable<BankAccount> accounts = bankAccountRepository.findAll();
		List<BankAccount> result = new ArrayList<>();
		for (BankAccount acc : accounts) {
			result.add(acc);
			}
		return result;
		}
		
		@GetMapping("/{id}")
		public BankAccount getAccountById(@PathVariable String id ){
			return bankAccountRepository.findById(id).get();
			
		}	  
	  
		@GetMapping("/update/{id}")
		public BankAccount updadetAccountById(@PathVariable String id , @RequestBody BankAccount bankAccount) {
			BankAccount record = bankAccount;
			record.setAccountNo(id);
			return bankAccountRepository.save(record);
			
		}
	  
		@DeleteMapping("/{id}")
		public BankAccount deleAccountById(@PathVariable String id) {
			BankAccount record = bankAccountRepository.findById(id).get();
			bankAccountRepository.delete(record);
			return record;
		}
	  
	  
//	   @ResponseBody
//	   String home() {
//	       return "John "
//	       		+ "love"
//	    		+ " "
//	       		+ "Fu";
	       
	   }

	