import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
 selector: 'app-post-list',
 templateUrl: './post-list.component.html',
 styleUrls: ['./post-list.component.css']
})
export class postListComponent implements OnInit {
 posts: any[];
 form: FormGroup;
 constructor(private httpClient: HttpClient, private fb: FormBuilder) {
   this.form = this.fb.group({
     name: '',
     email: ''
   });
 }

 ngOnInit() {
   this.httpClient
     .get('http://codecamp3-simple-api.herokuapp.com/api/posts')
     .subscribe(result => {
       this.posts = result as any[];
     });
 }
}

